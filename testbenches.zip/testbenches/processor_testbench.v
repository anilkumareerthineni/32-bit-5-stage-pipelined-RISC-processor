`timescale 1ns / 1ps
`include "risc_processor.v"

module processor_tb;

  // ==========================================
  // 1. Clock
  // ==========================================
  reg clk;


  // ==========================================
  // 2. DUT
  // ==========================================
  risc_processor risc (
    .clk(clk)
  );


  // ==========================================
  // 3. Clock Generator
  // ==========================================
  initial begin
    clk = 0;
    forever #10 clk = ~clk;   // 20ns period
  end


  // ==========================================
  // 4. TASK: Load Instruction Into IMEM
  // ==========================================
  task load_instr;
    input [15:0] addr;
    input [15:0] instr;
    begin
      risc.dp.im.memory[addr] = instr;

      $display("IMEM LOAD | Addr=%0d Instr=%h",
                addr, instr);
    end
  endtask


  // ==========================================
  // 5. TASK: Reset / Initialize PC
  // ==========================================
  task reset_pc;
    input [15:0] start_addr;
    begin
      @(posedge clk);

      risc.dp.pc_cur = start_addr;

      $display("PC RESET -> %0d", start_addr);
    end
  endtask


  // ==========================================
  // 6. TASK: Run CPU for N Cycles
  // ==========================================
  task run_cycles;
    input integer cycles;
    integer i;
    begin
      for (i = 0; i < cycles; i = i + 1)
        @(posedge clk);

      $display("CPU RAN %0d CYCLES", cycles);
    end
  endtask


  // ==========================================
  // 7. TASK: Dump Register File (Optional Debug)
  // ==========================================
  task dump_regs;
    integer i;
    begin
      $display("------ REGISTER FILE ------");
      for (i = 0; i < 8; i = i + 1)
        $display("R[%0d] = %0d", i,
          risc.dp.rf.reg_array[i]);
      $display("---------------------------");
    end
  endtask


  // ==========================================
  // 8. MAIN TEST PROGRAM
  // ==========================================
  initial begin

    $dumpfile("risc_processor.vcd");
    $dumpvars(5, processor_tb);

    // ----------------------------------
    // Initialize
    // ----------------------------------
    reset_pc(16'd0);

    // ----------------------------------
    // Load Program
    // ----------------------------------
    load_instr(0, 16'h02AB);
    load_instr(1, 16'h03B7);
    load_instr(2, 16'h2234);
    load_instr(3, 16'hC123);

    // ----------------------------------
    // Run Program
    // ----------------------------------
    run_cycles(20);

    // ----------------------------------
    // Check Results
    // ----------------------------------
    dump_regs();

    #20;
    $finish;
  end

endmodule
