`timescale 1ns / 1ps
`include "control_unit.v"

module control_unit_tb;

  // ==========================================
  // 1. DUT Signals
  // ==========================================
  reg  [3:0] opcode;

  wire [1:0] alu_op;
  wire jump, beq, bne, mem_read, mem_write,
       alu_src, reg_dst, mem_to_reg, reg_write;


  // ==========================================
  // 2. DUT Instantiation
  // ==========================================
  control_unit cu1(
    .opcode(opcode),
    .alu_op(alu_op),
    .jump(jump),
    .beq(beq),
    .bne(bne),
    .mem_read(mem_read),
    .mem_write(mem_write),
    .alu_src(alu_src),
    .reg_dst(reg_dst),
    .mem_to_reg(mem_to_reg),
    .reg_write(reg_write)
  );


  // ==========================================
  // 3. TASK: Apply Opcode Transaction
  // ==========================================
  task apply_opcode;
    input [3:0] op;
    begin
      opcode = op;

      #2;   // settle time for combinational logic

      $display("---------------------------------------------");
      $display("Time=%0t | OPCODE=%0d", $time, opcode);
      $display(" ALU_OP     = %b", alu_op);
      $display(" JUMP       = %b", jump);
      $display(" BEQ        = %b", beq);
      $display(" BNE        = %b", bne);
      $display(" MEM_READ   = %b", mem_read);
      $display(" MEM_WRITE  = %b", mem_write);
      $display(" ALU_SRC    = %b", alu_src);
      $display(" REG_DST    = %b", reg_dst);
      $display(" MEM_TO_REG = %b", mem_to_reg);
      $display(" REG_WRITE  = %b", reg_write);
    end
  endtask


  // ==========================================
  // 4. MAIN TEST SEQUENCE
  // ==========================================
  initial begin

    $dumpfile("control_unit.vcd");
    $dumpvars(0, control_unit_tb);

    // Initialize
    opcode = 0;
    #5;

    // -------------------------
    // Transactions
    // -------------------------
    apply_opcode(4'd0);
    apply_opcode(4'd1);
    apply_opcode(4'd2);
    apply_opcode(4'd3);
    apply_opcode(4'd4);
    apply_opcode(4'd5);
    apply_opcode(4'd7);
    apply_opcode(4'd9);
    apply_opcode(4'd10);
    apply_opcode(4'd12);
    apply_opcode(4'd13);
    apply_opcode(4'd14);
    apply_opcode(4'd15);

    #20;
    $finish;
  end

endmodule
