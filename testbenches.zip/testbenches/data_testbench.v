`timescale 1ns / 1ps
`include "data_memory.v"

module data_memory_tb;

  // ==========================================
  // 1. DUT Signals
  // ==========================================
  reg clk;
  reg write_en, read_en;
  reg [15:0] access_addr, write_data;

  wire [15:0] read_data;


  // ==========================================
  // 2. DUT Instantiation
  // ==========================================
  data_memory data1(
    .clk(clk),
    .write_en(write_en),
    .read_en(read_en),
    .access_addr(access_addr),
    .write_data(write_data),
    .read_data(read_data)
  );


  // ==========================================
  // 3. Clock Generation
  // ==========================================
  initial begin
    clk = 0;
    forever #10 clk = ~clk;   // 20ns period
  end


  // ==========================================
  // 4. TASK: Memory Write Transaction
  // ==========================================
  task mem_write;
    input [15:0] addr;
    input [15:0] data;
    begin
      @(posedge clk);

      write_en    = 1;
      read_en     = 0;
      access_addr = addr;
      write_data  = data;

      @(posedge clk);

      write_en = 0;

      $display("Time=%0t | WRITE | Addr=%0d Data=%0d",
                $time, addr, data);
    end
  endtask


  // ==========================================
  // 5. TASK: Memory Read Transaction
  // ==========================================
  task mem_read;
    input [15:0] addr;
    begin
      @(posedge clk);

      write_en    = 0;
      read_en     = 1;
      access_addr = addr;

      #2; // settle time

      $display("Time=%0t | READ  | Addr=%0d Data=%0d",
                $time, addr, read_data);

      @(posedge clk);
      read_en = 0;
    end
  endtask


  // ==========================================
  // 6. MAIN TEST SEQUENCE
  // ==========================================
  initial begin

    $dumpfile("data_memory.vcd");
    $dumpvars(0, data_memory_tb);

    // Initialize
    write_en    = 0;
    read_en     = 0;
    access_addr = 0;
    write_data  = 0;

    #5;

    // -------------------------
    // Transactions
    // -------------------------

    // Write then read back
    mem_write(16'd5, 16'd50);
    mem_read (16'd5);

    // Simultaneous read/write test
    @(posedge clk);
    write_en    = 1;
    read_en     = 1;
    access_addr = 16'd2;
    write_data  = 16'd99;

    #2;
    $display("Time=%0t | SIMUL R/W | Addr=%0d | Data=%0d | Read=%0d",
              $time, access_addr, write_data, read_data);

    @(posedge clk);
    write_en = 0;
    read_en  = 0;


    #20;
    $finish;
  end

endmodule
