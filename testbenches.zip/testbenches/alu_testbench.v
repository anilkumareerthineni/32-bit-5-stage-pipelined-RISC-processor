`timescale 1ns / 1ps
`include "alu.v"

module alu_tb;

  // ==========================================
  // 1. DUT Signals
  // ==========================================
  reg  [15:0] a, b;
  reg  [2:0]  alu_sel;

  wire [15:0] result;
  wire        zero_flag;


  // ==========================================
  // 2. DUT Instantiation
  // ==========================================
  alu alu_t(
    .a(a),
    .b(b),
    .alu_sel(alu_sel),
    .result(result),
    .zero_flag(zero_flag)
  );


  // ==========================================
  // 3. TASK: Apply ALU Transaction
  // ==========================================
  task apply_alu;
    input [15:0] op_a;
    input [15:0] op_b;
    input [2:0]  sel;
    begin
      a       = op_a;
      b       = op_b;
      alu_sel = sel;

      #2;   // settle time

      $display("---------------------------------------");
      $display("Time=%0t | A=%0d | B=%0d | SEL=%0d",
                $time, a, b, alu_sel);
      $display(" RESULT=%0d | ZERO=%b",
                result, zero_flag);
    end
  endtask


  // ==========================================
  // 4. MAIN TEST SEQUENCE
  // ==========================================
  initial begin

    $dumpfile("alu.vcd");
    $dumpvars(0, alu_tb);

    // Initialize
    a = 0;
    b = 0;
    alu_sel = 0;
    #5;

    // -------------------------
    // Test Operations
    // -------------------------

    // ADD
    apply_alu(16'd10, 16'd5,  3'd0);

    // SUB
    apply_alu(16'd15, 16'd8,  3'd1);

    // NOT A
    apply_alu(16'd0,  16'd0,  3'd2);

    // OR
    apply_alu(16'd45, 16'd45, 3'd6);

    // AND
    apply_alu(16'd30, 16'd15, 3'd5);

    // COMPARE
    apply_alu(16'd100,16'd200,3'd7);

    // LEFT SHIFT
    apply_alu(16'd256,16'd2,  3'd3);

    // RIGHT SHIFT
    apply_alu(16'd64, 16'd3,  3'd4);

    #20;
    $finish;
  end

endmodule
