`timescale 1ns / 1ps
`include "alu_control.v"

module alu_control_tb;

  // ==========================================
  // 1. DUT Signals
  // ==========================================
  reg  [1:0] ALU_op;
  reg  [3:0] opcode;

  wire [2:0] ALU_cnt;


  // ==========================================
  // 2. DUT Instantiation
  // ==========================================
  alu_control alu_cnt1(
    .ALU_op(ALU_op),
    .opcode(opcode),
    .ALU_cnt(ALU_cnt)
  );


  // ==========================================
  // 3. TASK: Apply ALU Control Transaction
  // ==========================================
  task apply_alu_ctrl;
    input [1:0] aluop;
    input [3:0] op;
    begin
      ALU_op = aluop;
      opcode = op;

      #2;   // settle time (combinational)

      $display("-------------------------------------");
      $display("Time=%0t | ALU_op=%b | opcode=%0d",
                $time, ALU_op, opcode);
      $display(" ALU_cnt = %b", ALU_cnt);
    end
  endtask


  // ==========================================
  // 4. MAIN TEST SEQUENCE
  // ==========================================
  initial begin

    $dumpfile("alu_control.vcd");
    $dumpvars(0, alu_control_tb);

    // Initialize
    ALU_op = 0;
    opcode = 0;
    #5;

    // -------------------------
    // ALU_op = 2'b10 (Fixed = 0)
    // -------------------------
    apply_alu_ctrl(2'b10, 4'd1);
    apply_alu_ctrl(2'b10, 4'd5);
    apply_alu_ctrl(2'b10, 4'd8);

    #5;

    // -------------------------
    // ALU_op = 2'b01 (Fixed = 1)
    // -------------------------
    apply_alu_ctrl(2'b01, 4'd1);
    apply_alu_ctrl(2'b01, 4'd2);
    apply_alu_ctrl(2'b01, 4'd5);

    #5;

    // -------------------------
    // ALU_op = 2'b00 (Opcode Dependent)
    // -------------------------
    apply_alu_ctrl(2'b00, 4'd3);
    apply_alu_ctrl(2'b00, 4'd4);
    apply_alu_ctrl(2'b00, 4'd6);
    apply_alu_ctrl(2'b00, 4'd12);

    #5;

    // -------------------------
    // ALU_op = 2'b11 (Unused → Default)
    // -------------------------
    apply_alu_ctrl(2'b11, 4'd6);

    #20;
    $finish;
  end

endmodule
