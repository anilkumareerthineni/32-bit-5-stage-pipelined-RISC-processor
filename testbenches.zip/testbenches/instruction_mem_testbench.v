`timescale 1ns / 1ps
`include "instruction_mem.v"

module instruction_mem_tb;

  // Signals
  reg  [15:0] pc;
  wire [15:0] instr_out;

  // DUT
  instruction_mem instr_mem1 (
    .pc(pc),
    .instr_out(instr_out)
  );

  // ================================
  // TASK: Send PC Transaction
  // ================================
  task apply_pc;
    input [15:0] pc_val;
    begin
      pc = pc_val;
      #5;   // Wait for output to settle

      $display("Time=%0t | PC=%0d | INSTR=%h",
               $time, pc, instr_out);
    end
  endtask


  // ================================
  // MAIN TEST
  // ================================
  initial begin

    // Dump for GTKWave
    $dumpfile("instruction_mem.vcd");
    $dumpvars(0, instruction_mem_tb);

    // Initialize
    pc = 0;
    #10;

    // Run transactions
    apply_pc(16'd8);
    apply_pc(16'd30);
    apply_pc(16'd57);
    apply_pc(16'd158);

    #20;
    $finish;

  end

endmodule
