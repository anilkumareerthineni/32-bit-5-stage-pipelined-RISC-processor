`timescale 1ns/1ps
`include "register_file.v"

module register_file_tb;

  // ==========================================
  // 1. DUT Signals
  // ==========================================
  reg clk;
  reg write_en;
  reg [2:0] read_addr1, read_addr2, write_addr;
  reg [15:0] write_data;

  wire [15:0] read_data1, read_data2;

  // ==========================================
  // 2. DUT Instantiation
  // ==========================================
  reg_file regfile1(
    .clk(clk),
    .write_en(write_en),
    .read_addr1(read_addr1),
    .read_addr2(read_addr2),
    .write_addr(write_addr),
    .write_data(write_data),
    .read_data1(read_data1),
    .read_data2(read_data2)
  );

  // ==========================================
  // 3. Clock Generation
  // ==========================================
  initial begin
    clk = 0;
    forever #10 clk = ~clk;   // 20ns period
  end


  // ==========================================
  // 4. TASK: Write Operation
  // ==========================================
  task write_reg;
    input [2:0] addr;
    input [15:0] data;
    begin
      @(posedge clk);
      write_en   = 1;
      write_addr = addr;
      write_data = data;

      @(posedge clk);
      write_en   = 0;

      $display("Time=%0t | WRITE | Addr=%0d Data=%0d",
                $time, addr, data);
    end
  endtask


  // ==========================================
  // 5. TASK: Read Operation
  // ==========================================
  task read_reg;
    input [2:0] addr1;
    input [2:0] addr2;
    begin
      read_addr1 = addr1;
      read_addr2 = addr2;

      #1; // small delay for combinational read

      $display("Time=%0t | READ  | R1(%0d)=%0d | R2(%0d)=%0d",
                $time,
                addr1, read_data1,
                addr2, read_data2);
    end
  endtask


  // ==========================================
  // 6. MAIN TEST SEQUENCE
  // ==========================================
  initial begin

    $dumpfile("register_file.vcd");
    $dumpvars(0, register_file_tb);

    // Initialize
    write_en   = 0;
    write_addr = 0;
    write_data = 0;
    read_addr1 = 0;
    read_addr2 = 0;

    // -------------------------
    // Transactions
    // -------------------------

    write_reg(3'd3, 16'd35);
    read_reg (3'd2, 3'd3);

    write_reg(3'd4, 16'd47);
    read_reg (3'd4, 3'd5);

    write_reg(3'd5, 16'd256);
    read_reg (3'd6, 3'd7);

    #20;
    $finish;
  end

endmodule
